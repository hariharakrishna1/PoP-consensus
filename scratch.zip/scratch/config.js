const DIFFICULTY =3;
const MINE_RATE=3000;
module.exports={DIFFICULTY,MINE_RATE};