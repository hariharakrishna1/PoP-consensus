const ws = require('ws');
const P2P_PORT=process.env.P2P_PORT || 5001;
const peers = process.env.PEERS?process.env.PEERS.split(','):[];

class p2pserver{
    constructor(blockchain){
        this.blockchain=blockchain;
        this.sockets=[];
    }

    listen(){
        const server = new ws.Server({port:P2P_PORT});
        server.on('connection',socket=> this.connectSocket(socket));
        this.connect2peers();
        console.log(`lisening for p2p from ${P2P_PORT}`);
        
    }
    connect2peers(){
        peers.forEach(peer=>{
            const socket=new ws(peer);
            socket.on('open',()=>this.connectSocket(socket));
        });
    }
    connectSocket(socket){
        this.sockets.push(socket);
        console.log('socket connected');
        this.handlemsg(socket);
        this.showchain(socket);
        
    }
    handlemsg(socket){
        socket.on('message',message=>{
            const data=JSON.parse(message);
            //console.log('data',data);
            this.blockchain.replacechain(data); 
        });
    }
    showchain(socket){
        socket.send(JSON.stringify(this.blockchain.chain));
    }
    chainsync(){
        this.sockets.forEach(socket =>this.showchain(socket))
    }

    portcheck()
    {
        //console.log(`${P2P_PORT}`);check port number
        return `${P2P_PORT}`;
    }

    gcsconsensus(){
        const x=Math.floor(Math.random() * 2);
        return x;
    }

    ownerconsensus(){
        const x=Math.floor(Math.random() * 2);
        return x;
    }
}
module.exports=p2pserver;
