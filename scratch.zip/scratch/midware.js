
const authpg= (permissions)=>{
    return(req,res,next)=>{
        const userrole=req.body.role
        if(permissions.includes(userrole)){
            
            next()
        }  
        else{
            return res.status(401).json("access denied");
        }
    }
}


const authblock=(req,res,next)=>{
    res.json("ACCESS DENIED"); 
}
module.exports={authpg,authblock};