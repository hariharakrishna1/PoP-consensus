const express=require('express');
const bodyparser=require('body-parser');
const B=require('./blockda/blockchain');
const p2p=require('./p2pserver');
const rateLimit = require("express-rate-limit");
const HTTP_PORT=process.env.HTTP_PORT || 3001;
const {authpg,authblock}=require('./midware');
const app=express();
app.use(bodyparser.json());//allows post request json scripts
const bc=new B();
const p=new p2p(bc); 

const limiter = rateLimit({
    windowMs: 10 * 60 * 1000, // 
    max: 4, // limit each IP to 50 requests per windowMs
    message: "Too many requests, please try again after 15 minutes"
  
    // this above message is shown to user when max requests is exceeded
    //(Hombergs, 2023)
  });
  


app.get('/instructions',(req,res)=>{
res.json(bc.chain);
});

app.post('/sendinstruction',authpg(["gcs","admin"]),limiter,(req,res)=>{
    //DEFAULT owner and GCS PORTS
   if(HTTP_PORT==3001 || HTTP_PORT==3002){    
        const block =bc.addblock(req.body.x,req.body.y,req.body.z);
        console.log(`new block added ${block.toString()}`);
        p.chainsync();
        res.redirect('/instructions');   
   }
    else{
        res.redirect('/');
    }
});

app.get('/',(req,res)=>{
    res.json("You require permission to send instructions. Head to /getconsensus along with your instructions");
});

//proof of permission on a public blockchain
app.post('/getconsensus',authpg(["external","uav"]),limiter,(req,res)=>{
    if(p.gcsconsensus()&&p.ownerconsensus())
    {
        const block =bc.addblock(req.body.x,req.body.y,req.body.z);
        console.log(`new block added ${block.toString()}`);
        p.chainsync();
        res.redirect('/instructions');
    }
    else{
        res.json("Permission denied ");
    }
});

app.listen(HTTP_PORT,()=> console.log(`Listening on port ${HTTP_PORT}`)); // common blockchain
p.listen(); //personal blockchain 

/*
References
Hombergs, T. (2023) How to implement API rate limiting in a Node.Js Express Application. https://reflectoring.io/tutorial-nodejs-rate-limiter/.
*/