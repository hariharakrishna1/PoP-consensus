const block=require('./block');

class blockchain{
constructor(){
    this.chain=[block.genesis()];
}

addblock(x,y,z){
//index of the last block sent into chain
    const nblock=block.miner(this.chain[this.chain.length-1],x,y,z);
    this.chain.push(nblock);
    return nblock;
}

validatechain(chain)
{
    if(JSON.stringify(chain[0])!==JSON.stringify(block.genesis())) //check if genesis block is same
        return false;

    for (let i=1;i<chain.length;i++)
    {
        const cb=chain[i];
        const lb=chain[i-1];
        if(cb.lasthash !== lb.hash || cb.hash!== block.hashblock(cb))
        return false;
    }
    return true;
}

replacechain(block1)
{
    if(block1.length <= this.chain.length){
        console.log("chain is not longer");
        return ;
    }
    //simultaneuos submission of same length chain below

    else if(!this.validatechain(block1))
    {
        console.log('received chain not valid');
        return;
    }
    console.log('replacing blockchain with new chain')
    this.chain=block1;
}
} 

module.exports=blockchain;