const SHA256=require('crypto-js/sha256');

class block{
    constructor(timestamp,hash,lasthash,x,y,z){
        //binds values entered to the current object
        this.timestamp=timestamp;
        this.hash=hash;
        this.lasthash=lasthash;
        this.x=x;
        this.y=y;
        this.z=z;
    }

    toString()
    {
        //es6 interpretation can 
        return `BLOCK: {
        TIMESTAMP:${this.timestamp},
        HASH     :${this.hash.substring(0,10)},
        Lasthash :${this.lasthash.substring(0,10)},
        DATA     :${this.x},
        DATA     :${this.y},
        DATA     :${this.z}
        }`;
    }
    static genesis()
    {
         return new this('first block','hashgenesis','lasthash',[],[],[]);
    }
   
static miner(lastblock,x,y,z)
{
    const time=Date.now();
    const lhash=lastblock.hash;
    const chash=block.encrypt(time,lhash,x,y,z);
    return new this(time,chash,lhash,x,y,z);
}

static encrypt(timestamp,lasthash,x,y,z)
{
    return SHA256(`${timestamp}${lasthash}${x}${y}${z}`).toString();
}
static hashblock(pblock)
{
    const { timestamp,lasthash,x,y,z}=pblock;
    return block.encrypt(timestamp,lasthash,x,y,z);
}
}

module.exports=block;