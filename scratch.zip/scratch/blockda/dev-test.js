  const block= require('./block');
 // const block1=new block('12:00','hash1','LASTHASH1','mydata');
  //console.log(block1.toString());
//console.log(block.genesis().toString());

  const oneblock=block.miner(block.genesis(),'mydata')//call genesis
  console.log(oneblock.toString());