const blockchain=require('./blockchain');
const block=require('./block');
describe('blockchain',()=>{
    let bchain,bc2;

    beforeEach(()=>{
        bchain=new blockchain();
        bc2=new blockchain();
    });

    it('genesis block test',()=>{
            expect(bchain.chain[0]).toEqual(block.genesis());
    });

    it('adds neew block',()=>{
        const data ='foo';
        bchain.addblock(data);
        
        expect(bchain.chain[bchain.chain.length-1].data).toEqual(data);
    });

    it('validates the chain',()=>{
        bc2.addblock('foo');
        expect(bchain.validatechain(bc2.chain)).toBe(true);
    });

    it('invalidates chain with corrput gen block',()=>{
        bc2.chain[0].data='corrput';//corrpting h=genesis block datatd
        expect(bchain.validatechain(bc2.chain)).toBe(false);
    });

    it('invalidate the corrupt chain',()=>{
        bc2.addblock('foo');//adding block to chain and then corrupting the data
        bc2.chain[1].data='not data';

        expect(bchain.validatechain(bc2.chain)).toBe(false);
    });

    it('replcaes chain with valid chain',()=>{
        bc2.addblock('fuu');//new block added
        bchain.replacechain(bc2.chain);//bchain has only genesis

        expect(bchain.chain).toEqual(bc2.chain); 
    });

    it('doesnt replace if legth less than or equal to ',()=>{
        bchain.addblock('foor');
        bchain.replacechain(bc2.chain);
        expect(bchain.chain).not.toEqual(bc2.chain);
    });
});