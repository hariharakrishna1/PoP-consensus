const test=require('./block');

describe('block',()=>{
    
    let data,lastblock,current;
    beforeEach(()=>{
        data='bar';
        lastblock=test.genesis();
        current=test.miner(lastblock,data);
    });

    it('checks the given input',()=>{
        expect(current.data).toEqual(data);
    });

    it('checks the `lasthash` of the previous block',()=>{
         expect(current.lasthash).toEqual(lastblock.hash);
    });
});
